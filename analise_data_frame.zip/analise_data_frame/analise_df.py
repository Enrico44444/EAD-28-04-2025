# Importa a bilbioteca pandas como pd
import pandas as pd

# Leitura do data frame com a pandas e coloca na variavel df
df = pd.read_csv('\\analise_data_frame\\datas\\Global_Cybersecurity_Threats.csv')

# Escreve as 5 primeiras linhas do df
print(df.head())

# Verifica se tem valores nulos e os soma se houver
print(df.isnull().sum())
# Sem valores null


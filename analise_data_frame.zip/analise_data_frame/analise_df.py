import pandas as pd

df = pd.read_csv('C:\\Users\\G A M E R\\Desktop\\analise_data_frame\\datas\\Global_Cybersecurity_Threats.csv')

print(df.head())

print(df.isnull().sum())
# Sem valores null

